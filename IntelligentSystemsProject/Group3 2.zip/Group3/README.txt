To run from terminal :

cd/foldername/ticTacToe3D.java

javac ticTacToe3D.java

java ticTacToe3D

To run from IDE:
Load the file and run.